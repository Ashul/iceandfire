// define angular module
var myApp = angular.module('myApp', ['ngRoute']);

